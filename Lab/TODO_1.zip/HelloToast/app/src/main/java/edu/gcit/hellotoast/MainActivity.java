package edu.gcit.hellotoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int rCount = 0;
    private TextView rShowCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rShowCount = (TextView) findViewById(R.id.CountTxt);
    }

    public void viewToast(View view) {
        Toast toast = Toast.makeText(this,R.string.toast_text, Toast.LENGTH_LONG);
        toast.show();
    }

    public void increment(View view) {
        rCount++;
        if (rShowCount != null)
            rShowCount.setText(Integer.toString(rCount));
    }
}